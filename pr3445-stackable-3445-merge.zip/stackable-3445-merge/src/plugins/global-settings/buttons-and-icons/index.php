<?php
/**
 * Global Spacing and Borders
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Stackable_Global_Buttons_And_Icons' ) ) {

	/**
	 * Stackable Global Block Spacing and Borders
	 */
    class Stackable_Global_Buttons_And_Icons {

		/**
		 * Initialize
		 */
  		function __construct() {
			// Register our settings.
			add_action( 'register_stackable_global_settings', array( $this, 'register_buttons_and_icons' ) );

			if ( is_frontend() ) {

				/**
				 * Global Spacing and Borders hooks
				 */
				// Add the Global Spacing and Borders styles in the frontend only.
				add_filter( 'stackable_inline_styles_nodep', array( $this, 'add_global_buttons_and_icons_styles' ) );
			}
		}

		/**
		 * Register the settings we need for global spacing and borders.
		 *
		 * @return void
		 */
		public function register_buttons_and_icons() {
			$four_range_properties = Stackable_Global_Settings::get_four_range_properties();
			$string_properties = Stackable_Global_Settings::get_string_properties();
			$number_properties = Stackable_Global_Settings::get_number_properties();

			register_setting(
				'stackable_global_settings',
				'stackable_global_buttons_and_icons',
				array(
					'type' => 'object',
					'description' => __( 'Stackable global buttons and icons', STACKABLE_I18N ),
					'sanitize_callback' => array( $this, 'sanitize_array_setting' ),
					'show_in_rest' => array(
						'schema' => array(
							'properties' => array(
								'--stk-button-min-height' => $number_properties,
								'--stk-button-padding' => $four_range_properties,
								'--stk-icon-button-padding' => $four_range_properties,
								'--stk-button-border-style' => $string_properties,
								'--stk-button-border-width' => $four_range_properties,
								'--stk-button-ghost-border-width' => $four_range_properties,
								'--stk-button-border-radius' => $four_range_properties,
								'--stk-button-box-shadow' => $string_properties,
								'--stk-button-icon-size' => $number_properties,
								'--stk-button-icon-gap' => $number_properties,
								'--stk-button-column-gap' => $number_properties,
								'--stk-button-row-gap' => $number_properties,

								'--stk-icon-list-size' => $number_properties,
								'--stk-icon-list-row-gap' => $number_properties,
								'--stk-icon-list-icon-gap' => $number_properties,
								'--stk-icon-list-indentation' => $number_properties,

								'--stk-icon-size' => $number_properties
							)
						)
					),
					'default' => '',
				)
			);
		}

		public function sanitize_array_setting( $input ) {
			return ! is_array( $input ) ? array( array() ) : $input;
		}

		/**-----------------------------------------------------------------------------
		 * Global Buttons and Icons functions
		 *-----------------------------------------------------------------------------*/
		/**
		 * Add our global buttons and Icons styles in the frontend.
		 *
		 * @param String $current_css
		 * @return String
		 */
		public function add_global_buttons_and_icons_styles( $current_css ) {
			$defaults = json_decode( file_get_contents( plugin_dir_path( __FILE__ ) . 'defaults.json' ), true );

			$generated_css = Stackable_Global_Settings::generate_global_block_layouts( 'stackable_global_buttons_and_icons', 'Global Buttons and Icons', $defaults );

			if ( ! $generated_css ) {
				return $current_css;
			}

			if ( strpos( $generated_css, 'hover' ) !== false ) {
				add_filter( 'stackable_has_global_animations', function( $has_global_animations ) {
					return true;
				} );
			}

			$current_css .= $generated_css;
			return apply_filters( 'stackable_global_frontend_css' , $current_css );
		}
	}

	new Stackable_Global_Buttons_And_Icons();
}
