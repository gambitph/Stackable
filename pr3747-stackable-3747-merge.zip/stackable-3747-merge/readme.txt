=== Stackable - Page Builder Gutenberg Blocks ===
Contributors: bfintal, gambitph
Tags: blocks, gutenberg, gutenberg blocks, page builder, WordPress blocks
Requires at least: 6.9
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 3.20.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

The complete website builder for the WordPress block editor. Build professional sites faster with powerful blocks, block styles, and a global design system.

== Description ==

**The Ultimate Companion to the WordPress Block Editor**

[Stackable](https://wpstackable.com?utm_source=wp-repo&utm_campaign=readme&utm_medium=link) is the ultimate trusted block plugin you've been waiting for. Build dynamic websites with our powerful yet lightweight custom WordPress blocks, global design system, ready-made designs, global settings, and advanced customization options all whilst boasting speedy performance. Have the confidence to easily design professional websites that stand out using a new page building experience for Gutenberg - the WordPress Block Editor.

> [Try our live demo](https://wpstackable.com/demo/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link) | [Join the Facebook Community](https://www.facebook.com/groups/wpstackable/)

[youtube https://www.youtube.com/watch?v=ZSo3t1l5tHQ]

## Transform Gutenberg into a Page Builder.

Stackable is the all-in-one block plugin for creating stunning websites by transforming the WordPress Block Editor into a Page Builder. Stackable has helped thousands of bloggers, merchants, marketers, designers and web development professionals make the most out of the WordPress Block Editor through fast, powerful and intuitive features.

## Global Design System

Design faster and more efficiently with our global controls, which make designing in one place and applying it to your entire site a breeze.

- Inherit styles from your Block Theme
- Theme.json 
- Pattern Library
- Full Page Templates
- Global Design System
- Global Color Schemes
- Global Typography
- Global Spacing, Borders, Buttons and Icons

## Ready Made Designs & Patterns

Enjoy an impressive Design Library to jumpstart your designing process. Never start from scratch and design like a pro with the help of our stunning and professionally-made designs and templates.

- Hundreds of ready-made designs
- Dozens of ready-made page templates
- Designs that inherit the styles of your block theme
- Dozens of block layouts
- Various shape separator designs

## Powerful Custom Blocks

Get 42 flexible custom WordPress blocks that are feature-rich and look good out of the box, and provide a robust foundation for any website even without a single line of code.

You can choose which of these blocks you need, depending on your workflow. You can also disable blocks if you don't need them.

**Essential Blocks**

- Advanced Columns Block — [View Block](https://wpstackable.com/columns-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Advanced Heading Block - [View Block](https://wpstackable.com/advanced-heading-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Advanced Text Block - [View Block](https://wpstackable.com/advanced-text-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Advanced Image Block
- Icon List Block — [View Block](https://wpstackable.com/icon-list-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Button Block — [View Block](https://wpstackable.com/button-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Icon Button Block
- Icon Block — [View Block](https://wpstackable.com/icon-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

**Special Blocks**

- Carousel Block - [View Block](https://wpstackable.com/carousel-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Horizontal Scroller Block - [View Block](https://wpstackable.com/horizontal-scroller-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Tabs Block - [View Block](https://wpstackable.com/tabs-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Countdown Block - [View Block](https://wpstackable.com/countdown-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Timeline Block - [View Block](https://wpstackable.com/timeline-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Table of Contents Block - [View Block](https://wpstackable.com/table-of-contents-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Posts Block — [View Block](https://wpstackable.com/blog-posts-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Image Box Block — [View Block](https://wpstackable.com/image-box-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Video Popup Block — [View Block](https://wpstackable.com/video-popup-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Progress Circle Block — [View Block](https://wpstackable.com/progress-circle-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Progress Bar Block — [View Block](https://wpstackable.com/progress-bar-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Accordion Block — [View Block](https://wpstackable.com/accordion-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Map Block — [View Block](https://wpstackable.com/map-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Icon Label Block
- Social Buttons Block
- Card Block — [View Block](https://wpstackable.com/card-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Count Up Block — [View Block](https://wpstackable.com/count-up-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Number Box Block — [View Block](https://wpstackable.com/number-box-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Notification Block — [View Block](https://wpstackable.com/notification-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Expand / Show More Block — [View Block](https://wpstackable.com/expand-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Separator Block — [View Block](https://wpstackable.com/separator-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Subtitle Block
- Price Block
- Divider Block
- Spacer Block

**Section Blocks**

- Hero Block — [View Block](https://wpstackable.com/header-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Call to Action Block — [View Block](https://wpstackable.com/call-to-action-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Feature Block — [View Block](https://wpstackable.com/feature-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Feature Grid Block — [View Block](https://wpstackable.com/feature-grid-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Pricing Box Block — [View Block](https://wpstackable.com/pricing-table-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Icon Box Block
- Testimonial Block — [View Block](https://wpstackable.com/testimonial-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Team Members Block — [View Block](https://wpstackable.com/team-member-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Blockquote Block — [View Block](https://wpstackable.com/blockquote-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

## Page Builder-like Design Options

Turn the WordPress Block Editor into a page builder. Fine-tune your creations with a wide range of familiar web design options.

- Block Theme & Theme.json Support
- Global Design System
- Multiple Block Layouts
- Flexbox Controls
- Image and Video Lightbox
- Save Block Defaults
- Customize block hover styles
- Block Background and Image Color Settings
- Block Typography Settings
- Image Shapes and Settings
- Advanced Gradient Color Picker
- Advanced Icon Options
- Advanced Column and Spacing Settings
- Global Colors & Typography Settings
- Responsiveness
    - Tablet and Mobile Column Arrangement
    - Live Responsive Editing
    - Ability to tweak designs for Tablet and Mobile views
    - Specify how Columns collapse in Tablet and Mobile
    - Hide / Show Specific Blocks on Desktop, Tablet or Mobile
    - Custom Tablet and Mobile breakpoints
- Custom `data-*` attributes

## Fast Page Loading Speed

Optimize your website’s performance, and get lightning fast page loading to make your site visitors stay. Have the chance to maximize your page speed insights and achieve high Core Web Vitals and higher SEO rankings.

- Loads the smallest file size possible of CSS and JS files in the frontend, ~ only 7.8kb total
- Adds almost no PHP server overhead for fast page loads
- Zero Bloat, no jQuery, no dependencies
- Optimized page loading with focus on Core Web Vitals
- Responsive image loading for faster browsing speeds in mobile devices
- Compatible with Optimization Plugins and use optimization techniques such as combining CSS and JS files and minification

## Integrations & Compatibility

Make your page building experience more well-rounded by using other popular tools. We've seamlessly integrated with these essential third-party plugins and tools:

- WPML
- Weglot
- Blocksy
- Toolset
- Font Awesome
- Google Fonts
- [see our full list of integrations and compatibility](https://wpstackable.com/compatibility/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

## Premium Features

Take web designing to the next level. Stackable Premium helps you unlock the full potential of the WordPress Block Editor with awesome advanced features that will give you the ability to create high-end websites.

### Dynamic Content (Premium)

Create dynamic WordPress websites that cater to the specific interests of visitors.

- Dynamic content
- Fully customize your query loops
- Site Custom Fields
- Conditionally display blocks

### More Integrations (Premium)

In premium, you get more integrations.

- WooCommerce
- ACF
- Metabox
- JetEngine

### Agency Tools (Premium)

Cater to more clients effectively and efficiently with our Agency Tools, which were specially made for web design professionals.

- Block CSS Customizer
- Role Manager

### Motion Effects (Premium)

Add animations that will bring your site to life and make it more visually engaging.

- Scroll Animations
- Entrance Animations
- Transform & Transition Effects

### More Blocks (Premium)

- Load More Block (for the Blog Posts Block)
- Pagination Block (for the Blog Posts Block)

> [Try our live demo](https://wpstackable.com/demo/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link) | [Learn more](https://wpstackable.com?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

### News Article Updates

- [v3.20 Saved Patterns and a Faster Design Library](https://wpstackable.com/blog/introducing-saved-patterns-and-a-faster-design-library/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.19 Full Page Templates, Style Guide and Onboarding Tour](https://wpstackable.com/blog/introducing-full-page-templates-style-guide-and-onboarding-tour/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.18 Global Block Styles](https://wpstackable.com/blog/introducing-block-styles/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.17 New Design Library](https://wpstackable.com/blog/introducing-the-new-design-library/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.16 Theme.json Support, Global Value Presets, Type Scale](https://wpstackable.com/blog/introducing-theme-json-support-global-value-presets-and-type-scale/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.15 Global Design System](https://wpstackable.com/blog/introducing-the-new-stackable-global-design-system/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.14 Icon Library & Granular Plugin Settings](https://wpstackable.com/blog/icon-library-granular-plugin-settings/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.13 Improved Stackable Server Performance](https://wpstackable.com/blog/improved-server-performance/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.12 WooCommerce Integration and Enhanced Color, Gradient and Opacity Settings](https://wpstackable.com/blog/woocommerce-integration/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.11 New Timeline Block](https://wpstackable.com/blog/introducing-new-timeline-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.10 New Tabs Block](https://wpstackable.com/blog/introducing-new-tabs-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.9 New Carousel Block](https://wpstackable.com/blog/introducing-new-carousel-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.8 New Stackable UI](https://wpstackable.com/blog/introducing-new-stackable-ui/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.7 New Horizontal Scroller and Countdown Blocks](https://wpstackable.com/blog/introducing-new-horizontal-scroller-and-countdown-blocks/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.6 New Progress Circle and Progress Bar Blocks](https://wpstackable.com/blog/introducing-new-progress-circle-and-progress-bar-blocks/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.5 No Bloat & Improved Performance](https://wpstackable.com/blog/improved-performance/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.4 Map Block](https://wpstackable.com/blog/introducing-map-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.3 Saving Block Defaults](https://wpstackable.com/blog/saving-block-defaults/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.2 Table of Contents Block](https://wpstackable.com/blog/table-of-contents-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.1 Wireframes](https://wpstackable.com/blog/introducing-wireframes/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v3.0 How To Shift From Version 2 to Version 3](https://wpstackable.com/blog/how-to-shift-from-version-2-to-version-3/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.17 Custom Attributes and Optimization](https://wpstackable.com/blog/custom-attributes-and-optimization/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.16 Clickable Containers and Pagination](https://wpstackable.com/blog/clickable-containers-and-pagination/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.15 Introducing Dynamic Content](https://wpstackable.com/blog/introducing-dynamic-content/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.14 Copy and Paste Block Styles](https://wpstackable.com/blog/copy-and-paste-block-styles/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.13 UI Kits, Borders & Improved Performance](https://wpstackable.com/blog/ui-kits-borders/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.12 Better User Interface and User Experience](https://wpstackable.com/blog/better-user-interface-and-user-experience/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.11 Introducing Global Colors and Global Typography](https://wpstackable.com/blog/global-colors-and-global-typography/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.10 Better Responsive Controls, Better List Block Icons and Low-Highlight Effect](https://wpstackable.com/blog/better-responsive-controls-better-list-block-icons-low-highlight-effect/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.9 Live Responsive Editing](https://wpstackable.com/blog/introducing-live-responsive-editing/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.8 Role Manager for Gutenberg](https://wpstackable.com/blog/introducing-role-manager-for-gutenberg/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.7 New Icon Block, Amazing Icons and Font Awesome Pro](https://wpstackable.com/blog/new-icon-block-amazing-icons-and-font-awesome-pro/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.6 New Advanced Blocks and Load More Blog Posts Button](https://wpstackable.com/blog/new-advanced-blocks-and-load-more-blog-posts-button/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.5 Better Onboarding for First Time Users](https://wpstackable.com/blog/better-onboarding-for-first-time-users/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.4 Introducing the Advanced Columns & Grid Block](https://wpstackable.com/blog/introducing-the-advanced-columns-and-grid-block/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.3 Introducing the Design Library and New Block Designs](https://wpstackable.com/blog/introducing-the-design-library-and-new-block-designs/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.2 Welcome Video, Better Separators and Auto-Block Recovery](https://wpstackable.com/blog/welcome-video-better-separators-and-auto-block-recovery/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.1 Help Video Snippets and Auto-Expand Settings](https://wpstackable.com/blog/help-video-snippets-auto-expand-settings/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- [v2.0 Version 2 is Out!](https://wpstackable.com/blog/version-2-is-out/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

### Learn More About Stackable - Page Builder Gutenberg Blocks & Designs

- Read our [documentation and tutorials](https://docs.wpstackable.com?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Visit our [site wpstackable.com](https://wpstackable.com?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)
- Subscribe to our [newsletter](http://eepurl.com/dJY9xI)

### Enjoying Stackable Blocks?

- Join the [Stackable Community in Facebook](https://www.facebook.com/groups/wpstackable/)
- Follow us in [Twitter @wpstackable](https://twitter.com/wpstackable)
- [Leave us a rating](https://wordpress.org/support/plugin/stackable-ultimate-gutenberg-blocks/reviews/?rate=5#new-post)

> ** Those marked with asterisks are part of Stackable Premium

== Installation ==

= Minimum Requirements =

You'll need WordPress version 6.8.1 or higher for this to work.

== Frequently Asked Questions ==

**Is Stackable Free?**

Yes, Stackable is free forever.

We have a premium version that adds more designs and advanced features. You may want to check [Stackable Premium here](https://wpstackable.com/premium/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link).

**Do I need to know how to code to use Stackable?**

No, you don't need to know a single line of code when using Stackable

**Do you have a live demo of what's in the Premium version?**

Yes, we have [live demo that you can check out here](https://wpstackable.com/demo/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link).

**What are Blocks?**

Blocks are the new shortcodes in WordPress 5.0 / Gutenberg. They're the basic elements that you add into your content to build your pages, like buttons, cards, videos, etc.

Stackable gives you an extensive collection of blocks that allows you to flexibly create any kind of professional landing page and front page.

**What themes can I use with Stackable?**

Stackable should work with any theme, we recommend using it with a block theme for the best experience.

**Can I disable blocks that I do not use?**

Yes, you can manage your blocks and choose what blocks to enable/disable.

**Can I use this plugin with other block plugins?**

Yes! Stackable blocks play well with other blocks.

**Can I use this add-on for other page builders I'm using?**

Nope. Stackable only works with Gutenberg, the new WordPress editor.

== Screenshots ==

1. Design Library with 375+ designs that fit your Block Theme
2. Global Settings that affect your entire site
3. Responsive Gutenberg Blocks
4. Powerful Custom Gutenberg Blocks
5. Page Builder-like Block Options

== Upgrade Notice ==

== Changelog ==

= 3.20.0 =
[v3.20 Saved Patterns and a Faster Design Library](https://wpstackable.com/blog/introducing-saved-patterns-and-a-faster-design-library/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

* New: Design Library - save and manage your own patterns (Premium) #3629
* New: Settings - default to theme margins for Heading blocks #3673
* New: Settings - default icon for Icon List block #3674
* Change: Dynamic Content - optimized PHP memory usage #1986
* Fixed: Design Library - faster previews and smoother browsing #3629
* Fixed: Editor - Safari responsive preview no longer freezes #3726
* Fixed: Yoast SEO - analysis highlighting works with Stackable blocks #3727
* Fixed: Icon List - improved Widgets screen performance #3728
* Fixed: Tabs block - Separator blocks now display correctly #3713
* Fixed: WooCommerce - product duplicates keep block attributes intact #3731
* Fixed: Design Library - no longer shows blank on fetch errors #3732
* Fixed: Custom CSS - no validation error after switching to Free #3734

= 3.19.10 =

* Change: Added input masking to Google API Key settings field #3714
* Fixed: Better Yoast plugin compatibility #3715
* Fixed: Blocks not reflecting the latest saved value in the frontend #3715
* Fixed: MailPoet - fixed compatibility with default Stackable text block #3718
* Fixed: Feature grid block - fixed justified columns #3717
* Fixed: Hardened deprecated block defaults endpoints #3725

= 3.19.9 =

* Fixed: Tablet and mobile preview styles now apply correctly in WP 7.0 #3711
* Fixed: Columns block - column justify now working when column wrapping is enabled #3703
* Fixed: Horizontal scroller - fixed first click handling issues #3697
* Fixed: Carousel - fixed JS error encountered with infinite scroll #3695
* Fixed: Tour - First Stackable tour closes right away #3699
* Fixed: Motion effects - fixed scroll position issue if there is a video near the top of the page #401
* Fixed: Image box - button group overlap #3706
* Fixed: Icon block - custom SVG can be not visible in the editor #3707

= 3.19.8 =

* Fixed: Dynamic content - prevent looping over itself when used with Query Loop block #2568
* Fixed: Dynamic content - improved performance #3160
* Fixed: Image block - fixed shape flip in iOS #3650
* Fixed: Admin UI improvements #3681
* Fixed: Text block - transforming to icon list now works properly #3682
* Fixed: Fixed rendering issues with lazy loaded images #3684
* Fixed: Icon block - fixed visual glitch in Safari #3687
* Fixed: Carousel block - loading issue edge case when used with display conditions #3688
* Fixed: Motion effects - loading issue when used together with display conditions #3693

= 3.19.7 =

* New: Additional 11 guided tours to help you master Stackable
* New: Posts block - you can now pick taxonomy terms for CPTs #3678
* Fixed: Posts block - formatting breaks on horizontal layouts #3554
* Fixed: Posts block - hover effects not working on some layouts #2583
* Fixed: Posts block - links are now not clickable in portfolio layouts #398

= 3.19.6 =

* Change: Carousels and Horizontal scroller block - images inside will not lazy load to prevent layout shifts #3672
* Change: Removed setting to enable/disable lazy loading of images inside carousels #3672
* Fixed: Posts block - improved text escaping #3669

= 3.19.5 =

* New: Icon list block - new option to retain custom SVG colors #3512
* Fixed: WordPress 6.9 compatibility - text block menu bar may get hidden #3654
* Fixed: WordPress 6.9 compatibility - better text compatibility #3654
* Fixed: Optimized icon performance inside the block editor  #3660
* Fixed: Global color scheme - when changing colors the drag handle jitters #3638
* Fixed: Displays correct value when selecting a theme color #3631
* Fixed: Block error encountered when getting filtered attributes #3646
* Fixed: Icon block - multicolor styling not applying correctly to some icons #3428
* Fixed: No longer queries WP API for useful plugins tab #3664
* Fixed: Removed Cimo cross marketing from premium build #3659
* Fixed: Ensure useful plugins tab is only visible if user has correct capabilities #3661

= 3.19.4 =
* New: Moved Stackable admin settings to its own top level menu #3633 #394
* New: Design Library module now lazy loads for faster initial loading performance #3597
* New: Added new `enqueue_frontend_assets_for_content( $content )` function for enqueueing js & css files in the current page #3634
* Change: Added notice for Cimo in relevant areas #3635 #3642
* Fixed: Global typography - resets for tablet and mobile when reseting for desktop #3550
* Fixed: Table of contents - scroll top effect not working properly #3640
* Fixed: Video popup - update date error on newly uploaded videos #3641

= 3.19.3 =
* Fixed: Display Condition - PHP warning when using date & time condition #395

= 3.19.2 =
* Fixed: Blocksy theme styles now reflected in the Design Library #3630
* Fixed: Rendering issues in design library when switching categories #3627
* Fixed: Carousel block - fixed content wide not followed #3628

= 3.19.1 =
* Fixed: Color schemes - some styles can change when there is a color scheme present #3624
* Fixed: Carousel block - console error when carousel is sliding #3615
* Fixed: Carousel block - content alignment does not get followed #3616
* Fixed: Posts block - html inside Read More link show incorrectly #3618
* Fixed: Transform origin settings reset back to defaults #3608
* Fixed: Content alignment option are not applied to native Image Blocks #3601

= 3.19.0 =
[Introducing: Full Page Templates, Style Guide and Onboarding Tour](https://wpstackable.com/blog/introducing-full-page-templates-style-guide-and-onboarding-tour/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

* New: Full Page Templates - Check the new "Pages" tab in the Design Library, with 40 Page Templates
* New: Design System Style Guide - See an exportable preview of your entire Design System
* New: Interactive Onboarding Tour - Learn Stackable with a step-by-step interactive tour inside the editor
* Change: Design Library - now hidden from the inserter #3581
* Fixed: Minor block accessibility issues #3593
* Fixed: Price Block - color schemes do not apply properly #3592
* Fixed: JavaScript editor warnings #3584
* Fixed: Design Library - better rendering of items #3591
* Fixed: Carousel Block - columns can overlap in infinite scroll #3588
* Fixed: Design System - orange modified indicator does not show up in the Global Color Palette #3576
* Fixed: Global Color Palette - you cannot drag the color picker #3575
* Fixed: Minor WPML compatibility issue when fields are missing #3603
* Fixed: Better permissions for editor Rest API endpoints #533ab8f
* Fixed: Minor UI improvements #3599 #391

= 3.18.1 =
* Fixed: Block styles - error encountered when creating divider and icon button block styles #3583
* Fixed: Role Manager settings doesn't display when changing the site language #3565
* Fixed: Auto-deactivate free/premium when another is acitvated and show an admin notice #3574
* Fixed: Block styles - show the correct block title when deleting a style #387
* Fixed: PHP error on stackable_add_welcome_notification when doing some REST API calls #3579

= 3.18.0 =

[Introducing: Global Block Styles](https://wpstackable.com/blog/introducing-block-styles/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

* New: Global Block Styles - you can now reuse block styles across your entire site #3541 #383
* Change: Removed Freemius SDK from the free version #3568
* Change: Stackable plugin settings is now called the Stackable Design System #3560
* Change: Block Defaults feature has been sunset, but with backward compatibility #3500
* Fixed: Carousel block - improved performance, especially in Safari #3561
* Fixed: Image block - added presets to border radius #3521
* Fixed: Posts block - corrected line-height for category text #3537
* Fixed: Image box block - image not displaying when using line layout #3493
* Fixed: Clean Global Typography CSS output #d51a38e
* Fixed: Optimized Google Font checking #3567
* Fixed: Added support for CSS optimizers that strip out the "px" from "0px" #3564
* Fixed: Added some missing string translations #3414

= 3.17.3 =
* Fixed: Stopped design library from being registered as patterns

= 3.17.2 =
* Fixed: Design Library - Updated CDN URL
* Fixed: If using non-English locale, Google Fonts may not load properly in the editor
* Fixed: Do not create a new design library block if there already is one

= 3.17.1 =
* Fixed: Progress circle block - having a prefix/suffix with dynamic content now works #3499
* Fixed: Image block - image becomes small when using a design library item then changing it to dynamic content #3522
* Fixed: Dyanmic content - dynamic content popup can go to the upper left #3523
* Fixed: Dynamic content - opening a dynamic field picker adds a vertical scrollbar for a split second #3524
* Fixed: Design library items show placeholders when registered as a pattern #3552
* Fixed: You can now use the same category names for user added patterns #3548
* Fixed: Some themes can trigger a JavaScript error preventing the global settings from opening #da8ce1d

[Introducing: New Design Library](https://wpstackable.com/blog/introducing-the-new-design-library/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

= 3.17.0 =
* New: Completely Revamped Design Library!
* New: Design Library - 375 new designs/patterns
* New: Design Library - now inherits block styles from the current block theme
* New: Design Library - now integrates Global Color Schemes

= 3.16.3 =
* Fixed: Preset values may double in some themes #3543
* Fixed: Using preset values with shadows will cause the preset value to reset on editor refresh #3538
* Fixed: Color Schemes - container colors now do not inherit the background color scheme #3534
* Fixed: Color Schemes - added setting to use old inheriting background color scheme behavior #3534
* Fixed: Columns block - fixed visual outline of column picker #dca1aa5
* Fixed: Corrected size of some icons in the block toolbar alignment button #4dd1872
* Fixed: Updated Freemius SDK to v2.12.1

= 3.16.2 =
* Fixed: Clicking on certain portions of the editor scrolls the editor downward #3520 #3529
* Fixed: Global settings - some themes produce an error in the editor #3532
* Fixed: Global settings - now visible for non-admin users in the editor #3531
* Fixed: Posts block - image overlay styles now work properly #3421 #3422

= 3.16.1 =
* Fixed: Hotfix for PHP error encountered if you have a tablet gloal typography font size #3526
* Fixed: Some preset controls now show blank values when not set #3519

= 3.16.0 =
[Introducing: Theme.json Support, Global Value Presets, Type Scale](https://wpstackable.com/blog/introducing-theme-json-support-global-value-presets-and-type-scale/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

* New: Theme.json support - relevant blocks now inherit styles from your block theme #3490
* New: Theme.json support - block theme preset values are now used by Stackable blocks #3474
* New: Typography Type Scale - choose from preset type scales for your typography #3474
* New: Global Value Presets - adjust preset values for font sizes, margins, paddings and more #3474 (premium)
* New: Added options to enable/disable block style inheritance and preset values #3474 #3490
* New: Video popup block - now outputs video schema #3402
* New: Dynamic Content - added User metadata #3129
* New: Added help links to manage global color schemes #3471
* New: Added integrations for WP Interactions #3497
* Fixed: Number box block - content alignment now works properly #3456
* Fixed: Dynamic content - date format is now translated properly #3464
* Fixed: Column order now supports up to max 20 inner columns #3491
* Fixed: Role Manager Settings - can appear blank #3494
* Fixed: Minor performance improvements on custom breakpoints #3477 #3496
* Fixed: Posts block - taxonomies for some post types may not query correctly #380

= 3.15.3 =
* Fixed: WordPress 6.8 compatibility
* Fixed: Disabling Show Global Color Schemes can cause block errors #3481
* Fixed: Block settings may not show up in the Theme Customizer #3484
* Fixed: Post block - sometimes the post date does not follow the timezone #3458

= 3.15.2 =
* Fixed: Hotfix new styles will not be applied now unless global color schemes and global styling are used

= 3.15.1 =
* Fixed: Hotfix background and container paddings having effects on hover
* Fixed: Hotfix remove theme compatibility for the time being for global color schemes since they're affecting colors

= 3.15.0 =
[Global Design System](https://wpstackable.com/blog/introducing-the-new-stackable-global-design-system/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

* New: Global Spacing and Layout - adjust spacing and layout across all blocks #3446
* New: Global Color Scheme - create color schemes and apply it to your entire site #3457 #371
* New: Global Typography Font Pairs - choose from preset font family pairs #3449 #370
* New: Added button text in Global Typography #3463
* New: Added modern font stacks to the font family option #3439
* Change: Google Fonts are now loaded asynchronously #df0adcc
* Fixed: Added placeholder text to the font family option #3440
* Fixed: Prevent multiple fetches in the admin settings page #3441
* Fixed: Google Fonts loaded with a delay in the editor #df0adcc
* Fixed: Icon Label Block - Icon Gap Resets to a Different Value When an Icon Size Is Set #3426

= 3.14.2 =
* New: Added support for Blocksy modern font stacks #3435
* New: Responsive breakpoint settings will now show Blocksy's breakpoints as the default value ce727ce
* Fixed: Responsive breakpoints - added better support for dynamically inserted content 6911ebe
* Fixed: Responsive breakpoints - now working properly in preview in some styles #3394
* Fixed: Number box - typography gradient color now works properly #3307
* Fixed: Icon list - typography gradient color now works properly #3309
* Fixed: Columns - nested columns may show up in different order on tablet or mobile if parent has different order #3398
* Fixed: Accordion block - may open upward if parent has different column arrangement #3406
* Fixed: Settings may appear blank because of browser caching #3419
* Fixed: Global settings - button does not appear in older WP versions #3425

= 3.14.1 =
* Fixed: Hotfix for EWWW Image Optimizer compatibility - freezing in the frontend if lazy loading and auto scaling are both enabled #3415

= 3.14.0 =
[Icon Library & Granular Plugin Settings](https://wpstackable.com/blog/icon-library-granular-plugin-settings/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

* New: Granular plugin settings - enhanced settings page for better control of plugin features #3354
* New: Added option to use an empty alt tag in images #3376
* Fixed: Image block - using small images no longer stretch #3239
* Fixed: Image block - switching between % and px width now doesn't cause the image to be too small or too big #3268
* Fixed: Dynamic Content - better compatibility with Blocksy Content Blocks #368
* Fixed: EWWW Image Optimizer compatibility - no longer causes blurry images #3296

= 3.13.13 =
* New: Icon Library (Premium feature) - you can now upload custom SVGs and re-use them for the Icon Block! #361 #3317
* Fixed: Text block: typing in the inspector will no longer escape html entities #3399
* Fixed: Typing in the middle of an option in the inspector will no longer move the cursor to the end #3396
* Fixed: Updated Freemius SDK to v2.11.0

= 3.13.12 =
* Fixed: Pasting text creates a new block instead of pasting on the current block #3371
* Fixed: Pasting on icon list block makes a new block and loses cursor placement #3382
* Fixed: Blocks inside a WooCommerce shop page can show css styles #3381
* Fixed: Clearing the icon from the icon picker can make the icon blank #3348
* Fixed: Sanitize titles for lightbox #3390
* Fixed: Enhanced text sanitazion #3391

= 3.13.11 =
* Fixed: Icon Label block: Error when missing an Icon block #3368
* Fixed: Disable Dynamic Content when inside the Customizer #3352
* Fixed: Allow pasting of blocks when focused on a Stackable Text Block #3330

= 3.13.10 =
* Fixed: Compatibility with WordPress 6.7 #3336
* Fixed: Better support for custom SVGs in the icon picker #3265
* Fixed: Cleanup of some code related to the previous performance update #3320
* Fixed: Accordion block: text can become unselectable #3350
* Fixed: Save default blocks: saving can be called multiple times and can cause the browser to hang #3355
* Fixed: Map block: prevent error when using a custom map marker #3362

= 3.13.9 =
* Fixed: Text blocks: text gradient color doesn't show for misspelled words #3305
* Fixed: Button block: adding a button block now places the cursor inside the button ##3324
* Fixed: Conditional display: inspector options do not re-render when changing values #3342
* Fixed: Optimized CSS: mobile styles can overwrite tablet styles sometimes (to fix, please re-save the page) #3345

= 3.13.8 =
* Fixed: Possible editor freezing when using deprecated icon lists inside patterns #3332
* Fixed: Timeline block: last timeline doesn't cut off in mobile view (part 2 of fix) #3292
* Fixed: Icon List block: can produce an error when migrating from an old version #3334
* Fixed: Prevent possible PHP error when calling kses too early

= 3.13.7 =
* Fixed: Stylesheets can sometimes not load in the frontend
* Fixed: SVG error when using custom SVGs with a use tag #3323
* Fixed: Carousel block: column alignment stops working for nested columns #3327
* Fixed: Global colors: color not copied over when pasting in another site #3329
* Fixed: Only do kses fixes when the user can edit posts

= 3.13.6 =
* New: Drastically improved performance of the Block Editor #3261
* New: Added option to enable Stackable Text block as the default editor block #3279
* New: Added `--stk-transition-default` CSS variable for easier transition customization #3266
* Change: Disable Inner Column block margins in Carousel blocks #3173
* Fixed: Posts block "<a" text may appear in post excerpts #3301
* Fixed: Improved performance of Stackable Global Colors #3299
* Fixed: Columns block: some settings may not work when used inside a Query Loop block #3109
* Fixed: Carousel block: slide orders change if used inside a Columns block with different responsive column orders #3113
* Fixed: Carousel block: fixed jumping and popup issues when infinite scrolling and autoplay are enabled #3287
* Fixed: Posts block: Load more can load the wrong data if you have multiple Posts block in a page #3189
* Fixed: Icon List block: transforming to this block can cause errors #3277
* Fixed: Horizontal Scroller block: images no longer dragged when dragging to scroll #3280
* Fixed: Timeline block: last timeline doesn't cut off in mobile view #3292

= 3.13.5 =
* Fixed: Otter Blocks compatibility #3276
* Fixed: Carousel block: Same-page navigation now works properly #3098
* Fixed: Some custom SVGs can interfere with othr uploaded custom SVGs #3265

= 3.13.4 =
* Fixed: Improved WordPress 6.6 compatibility and performance #357 #3258
* Fixed: Text block performance #3271
* Fixed: Carousel Block: Aria role errors when using infinite scrolling #3269
* Fixed: Media query shortcuts not working in Custom CSS #3214
* Fixed: Posts Block: Date now follows current website language setting #3241

= 3.13.3 =
* New: Enhanced WordPress 6.6 compatibility
* New: You can now select multiple adjacent same-type blocks and adjust their inspector settings at the same time #2711
* New: You can now pick a font family from the available ones in the Block Theme fonts or uploaded fonts #3195 #3244
* New: Faster pattern rendering in the editor #3229 #3225
* New: Added admin warning when settings page REST API fails #2882
* Change: Icon Label block: reworked Icon Gap option, now properly measures gap between icon and text #3126
* Fixed: Dynamic Content: using custom date format now works correctly #2570
* Fixed: Aspect Ratio tablet & mobile settings now working properly #3232
* Fixed: Hover transitions not smoothly transitioning #3207
* Fixed: Shadow color support for theme colors #3176
* Fixed: Bottom separator can sometimes not go behind the content #3061
* Fixed: Team Member block: fixed cover layout issue #2985

= 3.13.2 =
* New: Added new Aspect Ratio option to Image block and relevant blocks #3200
* New: Added filter stackable_force_css_load - when returning true, Stackable css files will always be loaded in the frontend even if no blocks are present #3218
* New: Accordion block - accordions show open when printing the webpage #3186
* Fixed: Posts block - empty excerpts may show some excerpt markup #3185
* Fixed: Posts block - excerpt length not being followed #3210
* Fixed: Load more block - clicking rapidly can load the same posts #2280
* Fixed: Accordion block - prevent highlighting text when toggling #3096
* Fixed: Accordion block - some icons in the content rotate when opening the accordion #3211
* Fixed: Table of Contents block - excluding headings can affect another TOC block in the same page #3197
* Fixed: Inner column block - top and bottom margins looks different in Firefox #3193
* Fixed: Some CSS validation errors #3087
* Fixed: Some custom SVG icons may not display properly #3103
* Fixed: Image blob shapes sometimes look different in Firefox #3042
* Fixed: Nested selectors in Custom CSS now work properly #3164
* Fixed: Security improvements

= 3.13.1 =
* Fixed: (Hotfix update): Style codes can show on some instances
* Fixed: Copy and paste styles now work correctly #350

= 3.13.0 =
[Improved Stackable Server Performance](https://wpstackable.com/blog/improved-server-performance/?utm_source=wp-repo&utm_campaign=readme&utm_medium=link)

* New: x2-x3 plugin performance - improved plugin execution times, reduced memory usage, and faster loading times #340 #3169 #347 #3178
* New: Performance improvements - options are now autoloaded correctly for better database performance #343 #3175
* New: Role Manager - when in content editing mode, a console warning will appear #2911
* Fixed: Dynamic Content - detected custom fields now show up in the Site Editor ##344
* Fixed: Carousel block - infinite scrolling also works for the previous button #3143
* Fixed: Full width buttons and flex wrapping now work correctly #3181
* Fixed: Button text now doesn't wrap - they look more like what you get in the editor #3181
* Fixed: Button group vertical alignment now works correctly on multiple buttons #3181
* Fixed: Copy and paste styles now work correctly if native blocks are used #341
* Fixed: ACF Dynamic Content line breaks in wysiwyg fields now do not get added #3110
* Fixed: Block preview error when using Stackable blocks in block patterns #3191

= 3.12.17 =
* Fixed: (Hotfix update): Display Conditions not working in some cases

= 3.12.16 =
* Fixed: Improved database performance of dynamic content when dealing with auto-detected meta fields #337
* Fixed: Transforming blocks to columns can produce block errors #3151
* Fixed: Dynamic content - possible Metabox error when using some fields #3156
* Fixed: Dynamic content - warning when using a featured image that has already been deleted #3168
* Fixed: Security improvements

= 3.12.15 =
* New: Tabs Block - added new option to set anchor links per tab that you can use to open each tab #3124
* New: Accordion Block - added support for anchor links that you can use to open each accordion block #3136
* Fixed: Accordion Block - now shows gradient colors with the correct z-index #3138
* Fixed: Accordion Block - removed video background option since it's not supported by browsers #3138
* Fixed: Metabox Settings - now shows properly other options registered in settings pages #335
* Fixed: Video Popup Block - prevent theme from adding button styles to the video popup #3121
* Fixed: Carousel Block - no longer clones slides when the screen is resized #3132
* Fixed: Carousel Block - DOM events now work correctly in slides when infinite scrolling is enabled #3137
* Fixed: Columns Block - block error when deleting a block in Firefox #3148

= 3.12.14 =
* Fixed: Table of Contents Block - WordPress 6.5 compatibility in the Site Editor #3133
* Fixed: Table of Contents Block - Auto-generate anchors now work after the editor refreshes #3133
* Fixed: (Hotfix) Rolled back separator fix since it was producing errors #3131
* Fixed: Some blocks may produce errors when editing in multisite when editing as a non-super user #3130
* Fixed: In multisite, prevent parts of custom icons from being stripped #3130
* Fixed: Buttons block - full width now occupies the entire full width correctly #2991
